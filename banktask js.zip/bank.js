var name1,
  age,
  deposit,
  withdraw,
  email,
  mobile,
  pswd = 123,
  bal = 500,
  pin,
  account,
  option;
function deposite() {
  account = prompt("Enter a/c no:");
  deposit = prompt("enter amount");
  bal = Number(bal) + Number(deposit);
  document.write("Balance:  " + bal);
}
function withdraws() {
  account = prompt("Enter a/c no:");
  pin = prompt("Enter your pin:");
  while (pin != pswd) {
    document.write("enter correct pin:", "<br/>");
    pin = prompt("enter your pin");
  }
  withdraw = prompt("enter amount");
  if (withdraw > bal) {
    document.write("Insuficiant balance");
    document.write("Balance:" + bal);
  } else {
    document.write("amount " + withdraw + " withdrawed" + "<br/>");
    bal = bal - Number(withdraw);
    document.write("balance:  " + bal);
  }
}

option = prompt(
  "Deposite - press d" + "   withdraw - press w" + "  create new a/c- press c"
);
if (
  option != "d" &&
  option != "w" &&
  option != "c" &&
  option != "D" &&
  option != "W" &&
  option != "C"
) {
  while (
    option != "d" &&
    option != "w" &&
    option != "c" &&
    option != "D" &&
    option != "W" &&
    option != "C"
  ) {
    document.write("enter correct option", "<br/>");
    option = prompt("Deposite - press d" + "   withdraw - press w");
  }
}
//deposite
switch (option) {
  case "d" || "D":
    deposite();
    break;

  //withdraw
  case "w" || "W":
    withdraws();
    break;

  //create account
  case "c" || "C":
    name1 = prompt("enter your name:");
    age = prompt("enter your age:");
    if (age < 18) {
      document.write("create a/c after 18 age");
    } else {
      email = prompt("enter email id:");
      mobile = prompt("enter mobile no:");
      pswd = prompt("create pin for a/c");
      bal = prompt("deposite some amount for a/c create");
      document.write("Thank you ! for create a/c" + "<br/>");
      document.write("don't forgot pin", "<br/>");
      document.write("YOUR DETAILS", "<br/>");
      document.write("your a/c no:001" + "<br/>");
      document.write(
        "name:" + name1,
        "<br/>",
        "age:" + age,
        "<br/>",
        "mobile no:" + mobile,
        "<br/>",
        "gmail:" + email,
        "<br/>",
        "balance:" + bal,
        "<br/>"
      );
      option = prompt("Deposite - press d" + "   withdraw - press w");
      if (option != "d" && option != "w" && option != "D" && option != "W") {
        while (
          option != "d" &&
          option != "w" &&
          option != "D" &&
          option != "W"
        ) {
          document.write("enter correct option", "<br/>");
          option = prompt("Deposite - press d" + "   withdraw - press w");
        }
      }
      switch (option) {
        case "d" || "D":
          deposite();
          break;
        case "w" || "W":
          withdraws();
          break;
        default:
          document.write("re-enter", "<br/>");
          break;
      }
    }
    break;
  default:
    document.write("enter correct", "<br/>");
    break;
}
